# PHbomber
smsbomber its only works in Philippines
## Disclaimer
⚠️ **Use at your own risk!** This tool is intended for educational purposes only, and I am not responsible for any misuse or damage caused.

# Installation and Usage
# Manual for termux
```
pkg install git
pkg install python3
git clone https://github.com/AkNOwn389/PHbomber
cd PHbomber
pip3 install -r requirements.txt
python3 run.py
```
# Manual for windows
```
# download and install python on python.org
# download and install git
# go on command promt
git clone https://github.com/AkNOwn389/PHbomber
cd PHbomber
pip install -r requirements.txt
python run.py
```
# Manual for linux
```
sudo apt install python3-pip
sudo apt install git
git clone https://github.com/AkNOwn389/PHbomber
cd PHbomber
pip install -r requirements.txt
python3 run.py
```
# ScreenShot
![Screenshot](https://github.com/AkNOwn389/PHbomber/blob/main/Screenshot_20221215-005531.jpg)

# Contributions
Contributions are welcome! If you find issues or want to improve the project, feel free to submit a pull request.

# License
This project is licensed under the MIT License. See the LICENSE file for details.

# Support
If you find this project helpful, consider buying me a coffee.

⚠️ Use responsibly and happy coding! ⚠️

<a href="https://buymeacoffee.com/dariusofficia10" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>
